/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vidamarinha;

import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet; 
import java.sql.SQLException;
import frm.login;
/**
 *
 * @author vpsia
 */
public class Vidamarinha {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        
         login meuLogin = new login();
         meuLogin.setLocationRelativeTo(null);
         meuLogin.setVisible(true);
         
         
        //PARTE QUE INSERE NAS TABELAS
        String url = "jdbc:mysql://localhost:3306/vidamarinha"; 
        String user = "root"; // Usuário padrão do MySQL 
        String password = ""; // Senha do MySQL (vazia por padrão no XAMPP) 

         try { 
            Class.forName("com.mysql.cj.jdbc.Driver");  
            Connection conn = DriverManager.getConnection(url, user, password);
            //String query = "INSERT INTO area (area, descrição)"
                  //  + " VALUES ('COP', 'Corinthians')";
            //PreparedStatement stmt = conn.prepareStatement(query);
            //stmt.execute();
            conn.close(); 
           } 
         catch (Exception e) { 
           e.printStackTrace(); 
        } 
        } 
        
    }

